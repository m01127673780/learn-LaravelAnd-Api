<?php
return [
          'news'   => 'News',
          'title'   => 'العنوان',
          'desc'    => 'Desc News',
          'add_by'  => 'Who Add By',
          'content' => 'Status News',
          'status'  => 'Status News',
];