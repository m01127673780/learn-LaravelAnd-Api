<?php

namespace App\Http\Controllers;
use App\News;
use Illuminate\Http\Request;
use View;
class NewsController extends Controller{

   public function all_news(Request $request ){
    $all_news = News::orderBy('desc','desk')->get(['title','add_by','desc','content','status','id']);
    return view ('layout.all_news',['all_news' => $all_news]);
     } 
}